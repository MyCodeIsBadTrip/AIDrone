from yamspy import MSPy
import sys
import json

SERIAL_PORT = "/dev/ttyS1"
# uart порт на котором висит контроллер

CMDS = {
    "roll": 1500,
    "pitch": 1500,
    "throttle": 0,
    "yaw": 1500,
    "aux1": 1000,
    "aux2": 1000,
}

CMDS_2 = None
# дефолтные значения

CMDS_ORDER = ["roll", "pitch", "throttle", "yaw", "aux1", "aux2"]
# порядок отправки. НЕ ТРОГАТЬ !

with MSPy(device=SERIAL_PORT, loglevel="WARNING", baudrate=115200) as board:
    if board == 1:
        print("Error: Unable to connect to the flight controller.")
        sys.exit(1)
    while True:
        CMDS_RC = [CMDS[ki] for ki in CMDS_ORDER]
        board.fast_msp_rc_cmd(CMDS_RC)

        input_data = sys.stdin.read()  # Получаем входящие данные
        CMDS_2 = json.loads(input_data)  # Преобразуем в словарь
        if CMDS_2:
            CMDS = CMDS_2
            CMDS_2 = None
