import cv2
import numpy as np
import time
import subprocess
import json

# from yamspy import MSPy

sensetivity_x = 50
sensetivity_y = 50
sensetivity_h = 50

CMDS = {
    "roll": 1500,
    "pitch": 1500,
    "throttle": 0,
    "yaw": 1500,
    "aux1": 1000,
    "aux2": 1000,
}
# дефолтные значения

# Подключение камеры
cap = cv2.VideoCapture(1)

# Загрузка предварительно обученной модели определения лица
face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")


def pause_and_switch():
    global process
    process = subprocess.Popen(
        ["/usr/bin/python3", "hearbeat.py"],
        stdin=subprocess.PIPE,  # Поддержка stdin для отправки данных
        stdout=subprocess.PIPE,  # Поддержка stdout для получения данных
        text=True,  # Используем строки вместо байтов
    )
    time.sleep(0.5)


while True:
    pause_and_switch()
    # CMDS["aux1"] = 1500

    # Захват кадра с камеры
    ret, frame = cap.read()

    # Преобразование кадра в оттенки серого
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Обнаружение лица на кадре
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    # Перебор всех обнаруженных лиц
    for x, y, w, h in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

        # Определение центра лица
        center_x = x + w // 2
        center_y = y + h // 2

        # Получение размеров кадра
        height, width, _ = frame.shape

        # Позиционирование камеры
        center_frame_x = width // 2
        center_frame_y = height // 2

        # Размеры предыдущего кадра
        old_frame_height = height

        if center_x < center_frame_x - sensetivity_x:
            # Движение дрона влево
            CMDS["yaw"] = CMDS["yaw"] + 10 if CMDS["yaw"] + 10 <= 2000 else CMDS["yaw"]
            pass
        elif center_x > center_frame_x + sensetivity_x:
            # Движение дрона вправо
            CMDS["yaw"] = CMDS["yaw"] - 10 if CMDS["yaw"] - 10 >= 1000 else CMDS["yaw"]
            pass
        if center_y < center_frame_y - sensetivity_y:
            # Движение дрона вверх
            CMDS["throttle"] = (
                CMDS["throttle"] + 10
                if CMDS["throttle"] + 10 <= 2000
                else CMDS["throttle"]
            )
            pass
        elif center_y > center_frame_y + sensetivity_y:
            # Движение дрона вниз
            CMDS["throttle"] = (
                CMDS["throttle"] - 10
                if CMDS["throttle"] - 10 >= 1000
                else CMDS["throttle"]
            )
            pass
        if old_frame_height < height - sensetivity_h:
            # Движение дрона вперёд
            CMDS["pitch"] = (
                CMDS["pitch"] + 10 if CMDS["pitch"] + 10 <= 2000 else CMDS["pitch"]
            )
            pass
        elif old_frame_height > height + sensetivity_h:
            # Движение дрона назад
            CMDS["pitch"] = (
                CMDS["pitch"] - 10 if CMDS["pitch"] - 10 >= 1000 else CMDS["pitch"]
            )
            pass

        # Отображение кадра с обнаруженными лицами
    cv2.imshow("Face Detection", frame)

    # Выход из цикла при нажатии клавиши 'q'
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

    process.stdin.write(json.dumps(CMDS))
    process.stdin.flush()

# Освобождение ресурсов и закрытие всех окон
cap.release()
cv2.destroyAllWindows()
CMDS["aux1"] = 1000
process.kill()
