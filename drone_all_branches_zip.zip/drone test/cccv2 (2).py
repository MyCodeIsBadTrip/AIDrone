import cv2
import numpy as np
from yamspy import MSPy
import time

# Параметры подключения к iNav SITL
port = 'COM1'  # Укажите порт, используемый для подключения к SITL
baudrate = 115200  # Скорость передачи данных

# Подключение к iNav
try:
    msp = MSPy(device=port, loglevel="WARNING", baudrate=baudrate)
    print("Соединение с iNav установлено.")
except Exception as e:
    print(f"Не удалось подключиться к iNav SITL: {e}")
    exit()

def follow_user(frame, drone, center_of_user):
    # Получаем размеры изображения
    height, width, _ = frame.shape
    
    # Центр изображения
    center_of_frame = (width // 2, height // 2)

    # Вычисляем смещение пользователя относительно центра изображения
    dx = center_of_user[0] - center_of_frame[0]
    dy = center_of_user[1] - center_of_frame[1]

    # Простая логика для движения дрона в зависимости от смещения
    if abs(dx) > 50:  # Если пользователь далеко по горизонтали
        if dx > 0:
            move_right(drone)
        else:
            move_left(drone)
    
    if abs(dy) > 50:  # Если пользователь далеко по вертикали
        if dy > 0:
            move_backward(drone)
        else:
            move_forward(drone)

def move_forward(drone):
    command = [1500, 1500, 1700, 1500]
    print(f"Sending command: {command} \u2191")
    drone.send_RAW_RC(command)

def move_backward(drone):
    command = [1500, 1500, 1300, 1500]
    print(f"Sending command: {command} \u2193")
    drone.send_RAW_RC(command)

def move_left(drone):
    command = [1300, 1500, 1500, 1500]
    print(f"Sending command: {command} \u2190")
    drone.send_RAW_RC(command)

def move_right(drone):
    command = [1700, 1500, 1500, 1500]
    print(f"Sending command: {command} \u2192")
    drone.send_RAW_RC(command)

def arm_drone(drone):
    # Предположим, что используется команда для установки режима "ARM"
    # Замените следующий код на метод, который правильно армит дрон.
    arm_command = [2000, 2000, 2000, 2000]  # Пример команды для ARming
    drone.send_RAW_RC(arm_command)
    print("Drone armed.")

def disarm_drone(drone):
    # Предположим, что используется команда для установки режима "DISARM"
    # Замените следующий код на метод, который правильно дисармит дрон.
    disarm_command = [1000, 1000, 1000, 1000]  # Пример команды для DISarming
    drone.send_RAW_RC(disarm_command)
    print("Drone disarmed.")

# Проверка подключения и получение данных от iNav
try:
    msp.send_RAW_RC([1500, 1500, 1500, 1500])  # Отправляем стандартный командный сигнал
    time.sleep(1)  # Даем время для получения ответа
    print("Соединение с iNav установлено и данные получены.")
except Exception as e:
    print(f"Ошибка при проверке соединения с iNav: {e}")
    exit()

# Инициализация камеры
cap = cv2.VideoCapture(0)

# ARMируем дрон
arm_drone(msp)

while True:
    # Чтение текущего кадра с камеры
    ret, frame = cap.read()
    if not ret:
        print("Не удалось получить кадр с камеры.")
        break

    # Преобразуем изображение в серую шкалу
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Используем каскад Хаара для обнаружения лица пользователя
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    faces = face_cascade.detectMultiScale(gray, 1.1, 4)

    # Если лицо обнаружено, вычисляем его центр
    for (x, y, w, h) in faces:
        center_of_user = (x + w//2, y + h//2)
        cv2.circle(frame, center_of_user, 5, (255, 0, 0), 2)
        
        # Управляем дроном
        follow_user(frame, msp, center_of_user)

    # Отображаем кадр
    cv2.imshow('Frame', frame)

    # Выход по нажатию клавиши 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# DISARMируем дрон перед завершением программы
disarm_drone(msp)

# Закрываем камеру
cap.release()
cv2.destroyAllWindows()
