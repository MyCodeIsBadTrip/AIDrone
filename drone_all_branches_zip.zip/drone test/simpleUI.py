import time
import curses
from collections import deque
from itertools import cycle
from yamspy import MSPy

# Max periods for:
CTRL_LOOP_TIME = 1 / 100
SLOW_MSGS_LOOP_TIME = 1 / 5  # these messages take a lot of time slowing down the loop...
NO_OF_CYCLES_AVERAGE_GUI_TIME = 10

# Настройки подключения через TCP
TCP_IP = "127.0.0.1"
TCP_PORT = 5762

def run_curses(external_function):
    result = 1
    try:
        # get the curses screen window
        screen = curses.initscr()

        # turn off input echoing
        curses.noecho()

        # respond to keys immediately (don't wait for enter)
        curses.cbreak()

        # non-blocking
        screen.timeout(0)

        # map arrow keys to special values
        screen.keypad(True)

        screen.addstr(
            1,
            0,
            "Press 'q' to quit, 'r' to reboot, 'm' to change mode, 'a' to arm, 'd' to disarm and arrow keys to control",
            curses.A_BOLD,
        )

        result = external_function(screen)

    finally:
        # shut down cleanly
        curses.nocbreak()
        screen.keypad(0)
        curses.echo()
        curses.endwin()
        if result == 1:
            print("An error occurred... probably the TCP connection is not available ;)")

def keyboard_controller(screen):

    CMDS = {
        "roll": 1500,
        "pitch": 1500,
        "throttle": 900,
        "yaw": 1500,
        "aux1": 1000,
        "aux2": 1000,
    }

    CMDS_ORDER = ["roll", "pitch", "throttle", "yaw", "aux1", "aux2"]

    try:
        screen.addstr(15, 0, "Connecting to the FC via TCP...")

        with MSPy(device='tcp:0.0.0.0:5760', loglevel="WARNING") as board:
            if board == 1:  # an error occurred...
                return 1

            screen.addstr(15, 0, "Connecting to the FC... connected!")
            screen.clrtoeol()
            screen.move(1, 0)

            average_cycle = deque([0] * NO_OF_CYCLES_AVERAGE_GUI_TIME)

            command_list = [
                "MSP_API_VERSION",
                "MSP_FC_VARIANT",
                "MSP_FC_VERSION",
                "MSP_BUILD_INFO",
                "MSP_BOARD_INFO",
                "MSP_UID",
                "MSP_ACC_TRIM",
                "MSP_NAME",
                "MSP_STATUS",
                "MSP_STATUS_EX",
                "MSP_BATTERY_CONFIG",
                "MSP_BATTERY_STATE",
                "MSP_BOXNAMES",
            ]

            if board.INAV:
                command_list.append("MSPV2_INAV_ANALOG")
                command_list.append("MSP_VOLTAGE_METER_CONFIG")

            for msg in command_list:
                if board.send_RAW_msg(MSPy.MSPCodes[msg], data=[]):
                    dataHandler = board.receive_msg()
                    board.process_recv_data(dataHandler)

            if board.INAV:
                cellCount = board.BATTERY_STATE["cellCount"]
            else:
                cellCount = 0  # MSPV2_INAV_ANALOG is necessary
            min_voltage = board.BATTERY_CONFIG["vbatmincellvoltage"] * cellCount
            warn_voltage = board.BATTERY_CONFIG["vbatwarningcellvoltage"] * cellCount
            max_voltage = board.BATTERY_CONFIG["vbatmaxcellvoltage"] * cellCount

            screen.addstr(15, 0, "apiVersion: {}".format(board.CONFIG["apiVersion"]))
            screen.clrtoeol()
            screen.addstr(
                15,
                50,
                "flightControllerIdentifier: {}".format(
                    board.CONFIG["flightControllerIdentifier"]
                ),
            )
            screen.addstr(
                16,
                0,
                "flightControllerVersion: {}".format(
                    board.CONFIG["flightControllerVersion"]
                ),
            )
            screen.addstr(
                16, 50, "boardIdentifier: {}".format(board.CONFIG["boardIdentifier"])
            )
            screen.addstr(17, 0, "boardName: {}".format(board.CONFIG["boardName"]))
            screen.addstr(17, 50, "name: {}".format(board.CONFIG["name"]))

            slow_msgs = cycle(["MSP_ANALOG", "MSP_STATUS_EX", "MSP_MOTOR", "MSP_RC"])

            cursor_msg = ""
            last_loop_time = last_slow_msg_time = last_cycleTime = time.time()
            while True:
                start_time = time.time()

                char = screen.getch()  # get keypress
                curses.flushinp()  # flushes buffer

                if char == ord("q") or char == ord("Q"):
                    break

                elif char == ord("d") or char == ord("D"):
                    cursor_msg = "Sending Disarm command..."
                    CMDS["aux1"] = 1000

                elif char == ord("r") or char == ord("R"):
                    screen.addstr(3, 0, "Sending Reboot command...")
                    screen.clrtoeol()
                    board.reboot()
                    time.sleep(0.5)
                    break

                elif char == ord("a") or char == ord("A"):
                    cursor_msg = "Sending Arm command..."
                    CMDS["aux1"] = 1800

                elif char == ord("m") or char == ord("M"):
                    if CMDS["aux2"] <= 1300:
                        cursor_msg = "Horizon Mode..."
                        CMDS["aux2"] = 1500
                    elif 1700 > CMDS["aux2"] > 1300:
                        cursor_msg = "Flip Mode..."
                        CMDS["aux2"] = 2000
                    elif CMDS["aux2"] >= 1700:
                        cursor_msg = "Angle Mode..."
                        CMDS["aux2"] = 1000

                elif char == ord("w") or char == ord("W"):
                    CMDS["throttle"] = (
                        CMDS["throttle"] + 10
                        if CMDS["throttle"] + 10 <= 2000
                        else CMDS["throttle"]
                    )
                    cursor_msg = "W Key - throttle(+):{}".format(CMDS["throttle"])

                elif char == ord("e") or char == ord("E"):
                    CMDS["throttle"] = (
                        CMDS["throttle"] - 10
                        if CMDS["throttle"] - 10 >= 1000
                        else CMDS["throttle"]
                    )
                    cursor_msg = "E Key - throttle(-):{}".format(CMDS["throttle"])

                elif char == curses.KEY_RIGHT:
                    CMDS["roll"] = (
                        CMDS["roll"] + 10 if CMDS["roll"] + 10 <= 2000 else CMDS["roll"]
                    )
                    cursor_msg = "Right Key - roll(-):{}".format(CMDS["roll"])

                elif char == curses.KEY_LEFT:
                    CMDS["roll"] = (
                        CMDS["roll"] - 10 if CMDS["roll"] - 10 >= 1000 else CMDS["roll"]
                    )
                    cursor_msg = "Left Key - roll(+):{}".format(CMDS["roll"])

                elif char == curses.KEY_UP:
                    CMDS["pitch"] = (
                        CMDS["pitch"] + 10
                        if CMDS["pitch"] + 10 <= 2000
                        else CMDS["pitch"]
                    )
                    cursor_msg = "Up Key - pitch(+):{}".format(CMDS["pitch"])

                elif char == curses.KEY_DOWN:
                    CMDS["pitch"] = (
                        CMDS["pitch"] - 10
                        if CMDS["pitch"] - 10 >= 1000
                        else CMDS["pitch"]
                    )
                    cursor_msg = "Down Key - pitch(-):{}".format(CMDS["pitch"])

                elif char == ord("n") or char == ord("W"):
                    CMDS["yaw"] = (
                        CMDS["yaw"] + 10 if CMDS["yaw"] + 10 <= 2000 else CMDS["yaw"]
                    )
                    cursor_msg = "N Key - throttle(+):{}".format(CMDS["throttle"])

                elif char == ord("m") or char == ord("E"):
                    CMDS["yaw"] = (
                        CMDS["yaw"] - 10 if CMDS["yaw"] - 10 >= 1000 else CMDS["yaw"]
                    )
                    cursor_msg = "M Key - throttle(-):{}".format(CMDS["throttle"])

                if (time.time() - last_loop_time) >= CTRL_LOOP_TIME:
                    last_loop_time = time.time()
                    if board.send_RAW_RC([CMDS[ki] for ki in CMDS_ORDER]):
                        dataHandler = board.receive_msg()
                        board.process_recv_data(dataHandler)

                if (time.time() - last_slow_msg_time) >= SLOW_MSGS_LOOP_TIME:
                    last_slow_msg_time = time.time()
                    next_msg = next(slow_msgs)

                    if board.send_RAW_msg(MSPy.MSPCodes[next_msg], data=[]):
                        dataHandler = board.receive_msg()
                        board.process_recv_data(dataHandler)

                    if next_msg == "MSP_ANALOG":
                        screen.addstr(
                            2,
                            0,
                            "voltage:{:.2f}V min_voltage:{}V warn_voltage:{}V max_voltage:{}V".format(
                                board.ANALOG["voltage"],
                                min_voltage,
                                warn_voltage,
                                max_voltage,
                            ),
                        )
                        screen.clrtoeol()

                    elif next_msg == "MSP_STATUS_EX":
                        screen.addstr(
                            3,
                            0,
                            "Armed:{} Buzzer:{} Msg:{} Beeper:{}".format(
                                board.STATUS_EX["armed"],
                                board.STATUS_EX["buzzer"],
                                board.STATUS_EX["mode"],
                                board.STATUS_EX["beeper"],
                            ),
                        )
                        screen.clrtoeol()

                    elif next_msg == "MSP_MOTOR":
                        screen.addstr(4, 0, "Motor Values:")
                        for index, motorValue in enumerate(board.MOTOR["motor"]):
                            screen.addstr(
                                5 + index,
                                0,
                                "Motor{}: {} ".format(index + 1, motorValue),
                            )
                        screen.clrtoeol()

                    elif next_msg == "MSP_RC":
                        screen.addstr(10, 0, "RC Values:")
                        for index, RCValue in enumerate(board.RC["channels"]):
                            screen.addstr(
                                11 + index, 0, "RC_channel{}: {}".format(index, RCValue)
                            )
                        screen.clrtoeol()

                average_cycle.popleft()
                average_cycle.append(start_time - last_cycleTime)
                last_cycleTime = start_time

                screen.addstr(
                    18,
                    0,
                    "GUI CycleTime:{:.2f}ms. Loop:{}ms".format(
                        (sum(average_cycle) / len(average_cycle)) * 1000,
                        (start_time - last_loop_time) * 1000,
                    ),
                )
                screen.clrtoeol()

                if cursor_msg:
                    screen.addstr(19, 0, cursor_msg)
                    screen.clrtoeol()
                    cursor_msg = ""

            if board.send_RAW_RC([1500, 1500, 900, 1500, 1000, 1000]):
                dataHandler = board.receive_msg()
                board.process_recv_data(dataHandler)

            if board.arm():
                print("Disarmed!" if board.DISARMED else "Armed!")

            time.sleep(0.5)

    except Exception as error:
        print("An error occurred:", str(error))
        return 1

    return 0


if __name__ == "__main__":
    run_curses(keyboard_controller)
