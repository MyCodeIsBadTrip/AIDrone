from yamspy import MSPy

SERIAL_PORT = "/dev/ttyS1"

CMDS = {
    "roll": 1800,
    "pitch": 1000,
    "throttle": 1000,
    "yaw": 1000,
    "aux1": 1000,
    "aux2": 1000,
}

CMDS_ORDER = ["roll", "pitch", "throttle", "yaw", "aux1", "aux2"]


with MSPy(device=SERIAL_PORT, loglevel="WARNING", baudrate=115200) as board:
    if board == 1:
        print("Error: Unable to connect to the flight controller.")

    if board.send_RAW_RC([CMDS[ki] for ki in CMDS_ORDER]):
        dataHandler = board.receive_msg()
        board.process_recv_data(dataHandler)
