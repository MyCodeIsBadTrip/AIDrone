import cv2
import numpy as np
from yamspy import MSPy

TCP_IP = "127.0.0.1"  # IP-адрес сервера
TCP_PORT = 5761          # Порт TCP
# параметры TCP-соединения с контроллером

CMDS = {
    "roll": 1800,
    "pitch": 1000,
    "throttle": 1000,
    "yaw": 1000,
    "aux1": 1000,
    "aux2": 1000,
}
# дефолтные значения

CMDS_ORDER = ["roll", "pitch", "throttle", "yaw", "aux1", "aux2"]
# порядок отправки. НЕ ТРОГАТЬ!

# Подключение камеры
cap = cv2.VideoCapture(0)

# Загрузка предварительно обученной модели определения лица
face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

with MSPy(device="COM2", loglevel="WARNING", baudrate=115200) as board:
    if board == 1:
        print("Error: Unable to connect to the flight controller.")
    while True:
        # Захват кадра с камеры
        ret, frame = cap.read()

        # Преобразование кадра в оттенки серого
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Обнаружение лица на кадре
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)

        # Перебор всех обнаруженных лиц
        for x, y, w, h in faces:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

            # Определение центра лица
            center_x = x + w // 2
            center_y = y + h // 2

            # Получение размеров кадра
            height, width, _ = frame.shape

            # Позиционирование камеры
            center_frame_x = width // 2
            center_frame_y = height // 2

            if center_x < center_frame_x - 50:
                # Движение камеры влево
                CMDS["yaw"] = (
                    CMDS["yaw"] + 10 if CMDS["yaw"] + 10 <= 2000 else CMDS["yaw"]
                )
            elif center_x > center_frame_x + 50:
                # Движение камеры вправо
                CMDS["yaw"] = (
                    CMDS["yaw"] - 10 if CMDS["yaw"] - 10 >= 1000 else CMDS["yaw"]
                )
            if center_y < center_frame_y - 50:
                # Движение камеры вверх
                CMDS["pitch"] = (
                    CMDS["pitch"] + 10 if CMDS["pitch"] + 10 <= 2000 else CMDS["pitch"]
                )
            elif center_y > center_frame_y + 50:
                # Движение камеры вниз
                CMDS["pitch"] = (
                    CMDS["pitch"] - 10 if CMDS["pitch"] - 10 >= 1000 else CMDS["pitch"]
                )

        # Отображение кадра с обнаруженными лицами
        cv2.imshow("Face Detection", frame)

        # Выход из цикла при нажатии клавиши 'q'
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

        if board.send_RAW_RC([CMDS[ki] for ki in CMDS_ORDER]):
            dataHandler = board.receive_msg()
            board.process_recv_data(dataHandler)

# Освобождение ресурсов и закрытие всех окон
cap.release()
cv2.destroyAllWindows()
